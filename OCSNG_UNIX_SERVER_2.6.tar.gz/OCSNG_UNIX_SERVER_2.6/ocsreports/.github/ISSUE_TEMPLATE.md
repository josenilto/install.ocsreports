*It's hard to solve a problem when important details are missing, that why we added this template, to help you and us.*

### General informations
Operating system : 

### Server installation method ( Only one choice )
- [ ] DEB Package
- [ ] RPM Package
- [ ] Install SH
- [ ] Manual installation

### Server informations
Php version : 
Mysql / Mariadb / Percona version : 
Apache version : 

### OCS Inventory informations
Ocsreports version : 

### Problem's description
*Describe your problem here*

